# Bober Client (Fabric, Minecraft 1.21.11, Yarn)

Bauen:   Gradle 9.x + Java 21 -> `gradle wrapper` -> `./gradlew build`
Testen:  `./gradlew runClient`
Jar:     build/libs/bober-client-0.2.0.jar -> mods-Ordner (Fabric Loader + Fabric API)

RShift = ClickGUI | Linksklick = an/aus | Rechtsklick = Settings

Module: Hitboxes, KillAura, TriggerBot | Sprint, Speed, Fly, Glide, AutoWalk | ESP, Fullbright, HUD | Sneak
Neues Modul: von `Module` erben, in `ModuleManager` eintragen, Settings via `add(...)`.

Hinweis: Nur fuer Singleplayer / eigene Server. Kein Anti-Cheat-Bypass enthalten.
