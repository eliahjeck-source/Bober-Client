package com.bober.client.module;

import com.bober.client.setting.NumberSetting;
import net.minecraft.util.math.Vec3d;

public class Speed extends Module {
    private final NumberSetting speed = add(new NumberSetting("Speed", 0.3, 0.1, 1.0));
    public Speed() { super("Speed", "Schnelleres Laufen.", Category.MOVEMENT); }
    @Override public void onTick() {
        var p = mc.player;
        if (p == null || !p.isOnGround()) return;
        float f = forward(), s = sideways();
        if (f == 0 && s == 0) return;
        double yaw = Math.toRadians(p.getYaw());
        double dx = -Math.sin(yaw) * f + Math.cos(yaw) * s;
        double dz = Math.cos(yaw) * f + Math.sin(yaw) * s;
        double len = Math.max(0.0001, Math.sqrt(dx * dx + dz * dz));
        Vec3d v = p.getVelocity();
        p.setVelocity(dx / len * speed.get(), v.y, dz / len * speed.get());
    }
}
