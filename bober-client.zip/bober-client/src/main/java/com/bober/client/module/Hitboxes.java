package com.bober.client.module;

import com.bober.client.setting.BoolSetting;
import com.bober.client.setting.NumberSetting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

public class Hitboxes extends Module {
    private final NumberSetting expand = add(new NumberSetting("Expand", 0.3, 0.0, 2.0));
    private final BoolSetting playersOnly = add(new BoolSetting("Players Only", true));
    public Hitboxes() { super("Hitboxes", "Vergroessert die Hitboxen (Targeting).", Category.COMBAT); }

    public float margin(Entity e) {
        if (mc.player == null || e == mc.player) return 0f;
        if (playersOnly.get() && !(e instanceof PlayerEntity)) return 0f;
        return expand.get().floatValue();
    }
}
