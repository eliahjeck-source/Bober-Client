package com.bober.client;

import com.bober.client.gui.ClickGui;
import com.bober.client.module.HUD;
import com.bober.client.module.Module;
import com.bober.client.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class BoberClient implements ClientModInitializer {
    public static final String NAME = "Bober Client";
    // Dunkelblaues Farbschema
    public static final int BG_TOP = 0xE0050B24, BG_BOTTOM = 0xE00B1B4D;
    public static final int PANEL = 0xFF0C1840;
    public static final int HEADER_A = 0xFF1E3A8A, HEADER_B = 0xFF0F2362;
    public static final int ACCENT = 0xFF1D4ED8;
    public static final int ON = 0xFF3B82F6;
    public static final int TEXT = 0xFFDBE7FF;
    public static final int DIM = 0xFF7F95C9;

    public static ModuleManager modules;
    private static boolean rsDown;

    public static int lerp(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    @Override public void onInitializeClient() {
        modules = new ModuleManager();

        // Rechts-Shift oeffnet die ClickGUI (per GLFW-Polling, nur ohne offenen Screen)
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            boolean down = GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
            if (down && !rsDown && mc.currentScreen == null) mc.setScreen(new ClickGui());
            rsDown = down;
            if (mc.player != null) modules.tick();
        });

        HudElementRegistry.attachElementAfter(VanillaHudElements.MISC_OVERLAYS,
            Identifier.of("boberclient", "hud"), (ctx, tickCounter) -> {
                HUD hud = modules.get(HUD.class);
                if (hud == null || !hud.isEnabled()) return;
                var mc = MinecraftClient.getInstance();
                var tr = mc.textRenderer;
                float time = (System.currentTimeMillis() % 4000) / 4000f;
                int y = 4;
                if (hud.watermark.get()) {
                    ctx.fill(2, 2, 8 + tr.getWidth(NAME), 13, 0xA0050B24);
                    ctx.fill(2, 2, 4, 13, ON);
                    ctx.drawTextWithShadow(tr, NAME, 7, 4, ON);
                    y += 13;
                }
                if (hud.fps.get()) { ctx.drawTextWithShadow(tr, mc.getCurrentFps() + " FPS", 4, y, TEXT); y += 10; }
                if (hud.coords.get() && mc.player != null) {
                    ctx.drawTextWithShadow(tr, String.format("XYZ %.1f %.1f %.1f",
                        mc.player.getX(), mc.player.getY(), mc.player.getZ()), 4, y, DIM);
                }
                if (hud.moduleList.get()) {
                    int w = ctx.getScaledWindowWidth(), ry = 3, i = 0;
                    for (Module m : modules.modules) {
                        if (!m.isEnabled() || m == hud) continue;
                        float t = hud.animated.get() ? (float) (0.5 + 0.5 * Math.sin((time - i * 0.08f) * Math.PI * 2)) : 0.5f;
                        int col = lerp(0xFF2563EB, 0xFF93C5FD, t);
                        int tw = tr.getWidth(m.name);
                        ctx.fill(w - tw - 7, ry - 1, w - 1, ry + 9, 0x90050B24);
                        ctx.fill(w - 3, ry - 1, w - 1, ry + 9, col);
                        ctx.drawTextWithShadow(tr, m.name, w - tw - 5, ry, col);
                        ry += 10; i++;
                    }
                }
            });
    }
}
