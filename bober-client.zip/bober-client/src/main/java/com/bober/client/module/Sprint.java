package com.bober.client.module;

public class Sprint extends Module {
    public Sprint() { super("Sprint", "Sprintet automatisch.", Category.MOVEMENT); }
    @Override public void onTick() {
        if (mc.player != null && forward() > 0 && !mc.player.horizontalCollision) mc.player.setSprinting(true);
    }
}
