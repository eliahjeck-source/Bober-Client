package com.bober.client.setting;

public class NumberSetting extends Setting<Double> {
    public final double min, max;
    public NumberSetting(String name, double def, double min, double max) {
        super(name, def); this.min = min; this.max = max;
    }
    @Override public void set(Double v) { value = Math.max(min, Math.min(max, v)); }
}
