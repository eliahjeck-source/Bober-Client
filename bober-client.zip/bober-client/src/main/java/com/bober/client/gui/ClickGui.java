package com.bober.client.gui;

import com.bober.client.BoberClient;
import com.bober.client.module.Module;
import com.bober.client.setting.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.*;

/** Eingabe per GLFW-Polling, damit die GUI nicht von Aenderungen der Screen-Input-API abhaengt. */
public class ClickGui extends Screen {
    private static final int W = 112, H = 14, GAP = 8;
    private final Set<Module> expanded = new HashSet<>();
    private NumberSetting dragging;
    private int dragX;
    private boolean lastL, lastR, lastRs = true;

    public ClickGui() { super(Text.literal("Bober Client")); }
    @Override public boolean shouldPause() { return false; }

    @Override public void render(DrawContext ctx, int mx, int my, float delta) {
        long h = MinecraftClient.getInstance().getWindow().getHandle();
        boolean l = GLFW.glfwGetMouseButton(h, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean r = GLFW.glfwGetMouseButton(h, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        boolean rs = GLFW.glfwGetKey(h, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
        boolean clickL = l && !lastL, clickR = r && !lastR;
        if (rs && !lastRs) { close(); return; }
        lastL = l; lastR = r; lastRs = rs;

        ctx.fillGradient(0, 0, width, height, BoberClient.BG_TOP, BoberClient.BG_BOTTOM);
        String title = BoberClient.NAME + "  |  RShift = schliessen  |  Rechtsklick = Settings";
        ctx.drawTextWithShadow(textRenderer, title, width / 2 - textRenderer.getWidth(title) / 2, 6, BoberClient.DIM);

        Module.Category[] cats = Module.Category.values();
        int total = cats.length * W + (cats.length - 1) * GAP;
        int x = width / 2 - total / 2;
        for (Module.Category cat : cats) {
            int y = 24;
            ctx.fillGradient(x, y, x + W, y + H + 2, BoberClient.HEADER_A, BoberClient.HEADER_B);
            ctx.drawTextWithShadow(textRenderer, cat.name(), x + 5, y + 4, BoberClient.TEXT);
            y += H + 2;
            for (Module m : BoberClient.modules.modules) {
                if (m.category != cat) continue;
                boolean hover = hit(mx, my, x, y);
                int bg = m.isEnabled() ? BoberClient.ON : (hover ? 0xFF14265E : BoberClient.PANEL);
                ctx.fill(x, y, x + W, y + H, bg);
                ctx.drawTextWithShadow(textRenderer, m.name, x + 5, y + 3, BoberClient.TEXT);
                if (!m.settings.isEmpty())
                    ctx.drawTextWithShadow(textRenderer, expanded.contains(m) ? "-" : "+", x + W - 10, y + 3, BoberClient.DIM);
                if (hover && clickL) m.toggle();
                if (hover && clickR && !m.settings.isEmpty() && !expanded.remove(m)) expanded.add(m);
                y += H;
                if (!expanded.contains(m)) continue;
                for (Setting<?> s : m.settings) {
                    boolean sh = hit(mx, my, x, y);
                    ctx.fill(x, y, x + W, y + H, 0xFF08112E);
                    if (s instanceof BoolSetting b) {
                        ctx.fill(x + 3, y + 3, x + 11, y + 11, b.get() ? BoberClient.ON : BoberClient.HEADER_B);
                        ctx.drawTextWithShadow(textRenderer, s.name, x + 15, y + 3, BoberClient.TEXT);
                        if (sh && clickL) b.toggle();
                    } else if (s instanceof NumberSetting n) {
                        double f = (n.get() - n.min) / (n.max - n.min);
                        ctx.fill(x, y, x + (int) (W * f), y + H, BoberClient.ACCENT);
                        ctx.drawTextWithShadow(textRenderer, s.name + " " + String.format("%.2f", n.get()), x + 5, y + 3, BoberClient.TEXT);
                        if (sh && clickL) { dragging = n; dragX = x; }
                    }
                    y += H;
                }
            }
            x += W + GAP;
        }
        if (dragging != null) {
            if (!l) dragging = null;
            else {
                double f = Math.max(0, Math.min(1, (mx - dragX) / (double) W));
                dragging.set(dragging.min + f * (dragging.max - dragging.min));
            }
        }
    }

    private boolean hit(int mx, int my, int x, int y) { return mx >= x && mx < x + W && my >= y && my < y + H; }
}
