package com.bober.client.module;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        modules.add(new Hitboxes());
        modules.add(new KillAura());
        modules.add(new TriggerBot());
        modules.add(new Sprint());
        modules.add(new Speed());
        modules.add(new Fly());
        modules.add(new Glide());
        modules.add(new AutoWalk());
        modules.add(new ESP());
        modules.add(new Fullbright());
        modules.add(new HUD());
        modules.add(new Sneak());
    }

    public void tick() { for (Module m : modules) if (m.isEnabled()) m.onTick(); }

    @SuppressWarnings("unchecked")
    public <T extends Module> T get(Class<T> c) {
        for (Module m : modules) if (c.isInstance(m)) return (T) m;
        return null;
    }
}
