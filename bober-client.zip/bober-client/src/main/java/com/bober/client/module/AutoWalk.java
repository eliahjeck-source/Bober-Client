package com.bober.client.module;

public class AutoWalk extends Module {
    public AutoWalk() { super("AutoWalk", "Laeuft automatisch vorwaerts.", Category.MOVEMENT); }
    @Override public void onTick() { mc.options.forwardKey.setPressed(true); }
    @Override public void onDisable() { mc.options.forwardKey.setPressed(false); }
}
