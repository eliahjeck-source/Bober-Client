package com.bober.client.module;

import com.bober.client.setting.BoolSetting;
import com.bober.client.setting.NumberSetting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;

public class KillAura extends Module {
    private final NumberSetting range = add(new NumberSetting("Range", 3.5, 1.0, 6.0));
    private final BoolSetting playersOnly = add(new BoolSetting("Players Only", false));
    public KillAura() { super("KillAura", "Greift Ziele in Reichweite an.", Category.COMBAT); }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) return;
        if (p.getAttackCooldownProgress(0.5f) < 1f) return;
        Entity best = null; double bd = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (e == p || !(e instanceof LivingEntity le) || !le.isAlive() || e instanceof ArmorStandEntity) continue;
            if (playersOnly.get() && !(e instanceof PlayerEntity)) continue;
            double d = p.distanceTo(e);
            if (d <= range.get() && d < bd) { bd = d; best = e; }
        }
        if (best != null) {
            mc.interactionManager.attackEntity(p, best);
            p.swingHand(Hand.MAIN_HAND);
        }
    }
}
