package com.bober.client.mixin;

import com.bober.client.BoberClient;
import com.bober.client.module.Hitboxes;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityMixin {
    // Vergroessert die Ziel-Hitbox (Crosshair-Targeting) – wie bei Hitbox-Modulen ueblich.
    @Inject(method = "getTargetingMargin", at = @At("HEAD"), cancellable = true)
    private void bober$margin(CallbackInfoReturnable<Float> cir) {
        if (BoberClient.modules == null) return;
        Hitboxes h = BoberClient.modules.get(Hitboxes.class);
        if (h == null || !h.isEnabled()) return;
        float m = h.margin((Entity) (Object) this);
        if (m > 0f) cir.setReturnValue(m);
    }
}
