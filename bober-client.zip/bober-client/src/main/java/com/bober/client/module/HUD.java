package com.bober.client.module;

import com.bober.client.setting.BoolSetting;

public class HUD extends Module {
    public final BoolSetting watermark = add(new BoolSetting("Watermark", true));
    public final BoolSetting fps = add(new BoolSetting("FPS", true));
    public final BoolSetting coords = add(new BoolSetting("Coordinates", true));
    public final BoolSetting moduleList = add(new BoolSetting("Module List", true));
    public final BoolSetting animated = add(new BoolSetting("Animated Gradient", true));
    public HUD() { super("HUD", "Zeigt Infos auf dem Bildschirm.", Category.RENDER); setEnabled(true); }
}
