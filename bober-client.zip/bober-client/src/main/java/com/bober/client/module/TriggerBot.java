package com.bober.client.module;

import com.bober.client.setting.BoolSetting;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;

public class TriggerBot extends Module {
    private final BoolSetting playersOnly = add(new BoolSetting("Players Only", false));
    public TriggerBot() { super("TriggerBot", "Schlaegt, sobald das Fadenkreuz ein Ziel trifft.", Category.COMBAT); }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null || mc.interactionManager == null) return;
        if (!(mc.crosshairTarget instanceof EntityHitResult hit)) return;
        if (playersOnly.get() && !(hit.getEntity() instanceof PlayerEntity)) return;
        if (p.getAttackCooldownProgress(0.5f) < 1f) return;
        mc.interactionManager.attackEntity(p, hit.getEntity());
        p.swingHand(Hand.MAIN_HAND);
    }
}
