package com.bober.client.module;

import com.bober.client.setting.NumberSetting;

public class Fly extends Module {
    private final NumberSetting speed = add(new NumberSetting("Speed", 0.05, 0.01, 0.5));
    public Fly() { super("Fly", "Fliegen (Singleplayer / eigene Server).", Category.MOVEMENT); }
    @Override public void onTick() {
        if (mc.player == null) return;
        mc.player.getAbilities().allowFlying = true;
        mc.player.getAbilities().setFlySpeed(speed.get().floatValue());
    }
    @Override public void onDisable() {
        if (mc.player == null) return;
        mc.player.getAbilities().setFlySpeed(0.05f);
        if (!mc.player.isCreative() && !mc.player.isSpectator()) {
            mc.player.getAbilities().allowFlying = false;
            mc.player.getAbilities().flying = false;
        }
    }
}
