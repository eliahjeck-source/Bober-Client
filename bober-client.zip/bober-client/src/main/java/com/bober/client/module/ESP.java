package com.bober.client.module;

import com.bober.client.setting.BoolSetting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;

/** Glow-ESP: markiert Entities mit dem Glow-Outline-Effekt (durch Waende sichtbar). */
public class ESP extends Module {
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting mobs = add(new BoolSetting("Mobs", true));
    public ESP() { super("ESP", "Outline-Glow durch Waende.", Category.RENDER); }

    @Override public void onTick() {
        if (mc.world == null) return;
        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player || !(e instanceof LivingEntity) || e instanceof ArmorStandEntity) continue;
            boolean want = (players.get() && e instanceof PlayerEntity) || (mobs.get() && e instanceof MobEntity);
            if (want && !e.isGlowing()) e.setGlowing(true);
            else if (!want && e.isGlowing()) e.setGlowing(false);
        }
    }
    @Override public void onDisable() {
        if (mc.world == null) return;
        for (Entity e : mc.world.getEntities()) if (e != mc.player && e.isGlowing()) e.setGlowing(false);
    }
}
