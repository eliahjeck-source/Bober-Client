package com.bober.client.module;

public class Sneak extends Module {
    public Sneak() { super("Sneak", "Schleicht dauerhaft.", Category.PLAYER); }
    @Override public void onTick() { mc.options.sneakKey.setPressed(true); }
    @Override public void onDisable() { mc.options.sneakKey.setPressed(false); }
}
