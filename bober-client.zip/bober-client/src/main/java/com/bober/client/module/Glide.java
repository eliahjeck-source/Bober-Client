package com.bober.client.module;

import com.bober.client.setting.NumberSetting;
import net.minecraft.util.math.Vec3d;

public class Glide extends Module {
    private final NumberSetting fall = add(new NumberSetting("Fallspeed", 0.05, 0.01, 0.3));
    public Glide() { super("Glide", "Langsames Fallen.", Category.MOVEMENT); }
    @Override public void onTick() {
        var p = mc.player;
        if (p == null || p.isOnGround()) return;
        Vec3d v = p.getVelocity();
        if (v.y < -fall.get()) p.setVelocity(v.x, -fall.get(), v.z);
    }
}
