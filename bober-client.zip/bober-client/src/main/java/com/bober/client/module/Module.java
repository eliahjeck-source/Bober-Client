package com.bober.client.module;

import com.bober.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    protected static final MinecraftClient mc = MinecraftClient.getInstance();
    public final String name, description;
    public final Category category;
    public final List<Setting<?>> settings = new ArrayList<>();
    private boolean enabled;

    public enum Category { COMBAT, MOVEMENT, RENDER, PLAYER }

    public Module(String name, String description, Category category) {
        this.name = name; this.description = description; this.category = category;
    }

    protected <S extends Setting<?>> S add(S s) { settings.add(s); return s; }

    public boolean isEnabled() { return enabled; }
    public void toggle() { setEnabled(!enabled); }
    public void setEnabled(boolean e) {
        if (e == enabled) return;
        enabled = e;
        if (e) onEnable(); else onDisable();
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}

    /** Bewegungsinput aus den Tasten (versionsunabhaengig). */
    protected static float forward() {
        return (mc.options.forwardKey.isPressed() ? 1f : 0f) - (mc.options.backKey.isPressed() ? 1f : 0f);
    }
    protected static float sideways() {
        return (mc.options.leftKey.isPressed() ? 1f : 0f) - (mc.options.rightKey.isPressed() ? 1f : 0f);
    }
}
